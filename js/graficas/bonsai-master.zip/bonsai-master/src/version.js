define(function() {
  return '0.4.5';
});
