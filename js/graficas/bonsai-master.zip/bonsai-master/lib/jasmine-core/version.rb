module Jasmine
  module Core
    VERSION = "1.2.0"
  end
end

