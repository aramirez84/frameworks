new Rect(0, 100, 100, 100).addTo(stage).attr({
  fillColor: 'yellow'
});
