// Within submovie. Submovie is at {100,100}, so this shape can be {0,0}
new Rect(0, 0, 100, 100).addTo(stage).attr({
  fillColor: 'green'
});
