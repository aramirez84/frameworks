plugin(function(bs) {
  return {
    canLoadPlugin: true
  };
});