setTimeout(function(){
  stage.post({
    command: 'testMovieIsRunning'
  });
}, 1);