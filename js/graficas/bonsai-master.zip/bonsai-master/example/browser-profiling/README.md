JS-based profiling
==================

- uses the built version of bonsai. Make sure to `make build` before profiling!
- must run on a php-enabled webserver that has connection to our VPN. PHP is
  used to proxy to our riak server at http://riak.ux:8098
- profiles don’t have build numbers and can only be distinguished by date
