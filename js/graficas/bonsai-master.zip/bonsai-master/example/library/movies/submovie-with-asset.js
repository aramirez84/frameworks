/**
 * submovie with asset
 */

stage.loadSubMovie('assets/submovies/redpanda.js', function(err, movie) {
	movie.addTo(stage);
});
