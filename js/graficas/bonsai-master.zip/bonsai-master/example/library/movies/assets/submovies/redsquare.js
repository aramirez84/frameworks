new Rect(0, 0, 100, 100).attr({
	fillColor: 'red'
}).addTo(stage);
