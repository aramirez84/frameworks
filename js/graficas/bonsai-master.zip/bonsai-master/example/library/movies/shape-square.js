/**
 * shape square
 */

new Rect(150, 150, 150, 150).attr({
  strokeWidth: 1,
  fillColor: 'red',
  opacity: 0.4
}).addTo(stage);
