/**
 * shape rotate
 */

stage.addChild(
  new Rect(0, 0, 150, 150)
    .attr({
      fillColor:'red',
      rotation: Math.PI/180*35,
      x:150,
      y:150
    })
);
