/**
 * shape attributes
 *
 * Path w/ attributes.
 */
var rectPath = new Rect(150, 150, 150, 150).attr({fillColor: 'red', strokeColor: 'green', strokeWidth: 5});

stage.addChild(rectPath);
