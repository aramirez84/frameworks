/**
 * audio tick
 */
var tick = new Audio('assets/tick16.m4a').addTo(stage);
stage.on('tick', function() {
   // soooooound!!
   //tick.play();
});
