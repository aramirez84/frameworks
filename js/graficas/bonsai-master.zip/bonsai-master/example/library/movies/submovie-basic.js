/**
 * submovie basic
 */

stage.loadSubMovie('assets/submovies/redsquare.js', function(err, movie) {
	movie.addTo(stage);
});
