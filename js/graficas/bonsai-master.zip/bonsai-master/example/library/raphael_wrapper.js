/**
 * This module is a wrapper for Raphael.
 *
 * It is needed for build environment as Raphael
 * needs to be excluded from build, and needs to
 * be a valid AMD compliant module.
 */
define([
  '../../lib/raphael/raphael-min'
], function() {
  return null;
});
