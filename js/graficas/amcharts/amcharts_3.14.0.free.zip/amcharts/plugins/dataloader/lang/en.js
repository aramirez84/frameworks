AmCharts.translations.dataLoader.en = {
  'Error loading file': 'Error loading file',
  'Error parsing JSON file': 'Error parsing JSON file',
  'Unsupported data format': 'Unsupported data format',
  'Loading data...': 'Loading data...'
}