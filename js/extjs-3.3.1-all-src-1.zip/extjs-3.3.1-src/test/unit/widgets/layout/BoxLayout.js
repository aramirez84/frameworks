/*!
 * Ext JS Library 3.3.1
 * Copyright(c) 2006-2010 Sencha Inc.
 * licensing@sencha.com
 * http://www.sencha.com/license
 */
/**
 * Tests Ext.data.Store functionality
 * @author Ed Spencer
 */
(function() {
    var suite  = Ext.test.session.getSuite('Ext.layout.BoxLayout'),
        assert = Y.Assert;
    
    // suite.add(new Y.Test.Case({
    //     name: 'parseMargins'
    // }));
    
})();